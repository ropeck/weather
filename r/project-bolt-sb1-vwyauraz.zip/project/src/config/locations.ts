export const locationCoordinates: Record<string, { lat: number; lng: number }> = {
  'Fogcat Farm': { lat: 47.8739, lng: -122.1839 },
  'seacliff': { lat: 36.9741, lng: -121.9158 }
};